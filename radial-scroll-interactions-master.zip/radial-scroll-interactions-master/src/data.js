export const DATA = [
  {
    id: null,
  },
  {
    id: 1,
    navId: 1,
    title: "Klim Musalimov",
    imgUrl:
      "https://images.unsplash.com/photo-1643992732075-b0b4e1eb8ac7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 2,
    title: "Artem Shuba ",
    imgUrl:
      "https://images.unsplash.com/photo-1644153505851-c1ff3606d2cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=986&q=80",
  },
  {
    id: 3,
    title: "Willian Justen de Vasconcellos",
    imgUrl:
      "https://images.unsplash.com/photo-1642772670616-d39320e41118?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 4,
    title: "Leon S",

    imgUrl:
      "https://images.unsplash.com/photo-1630025909220-2cee94dc913a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80",
  },
  {
    id: 5,
    title: "Natalia Yakovleva",
    imgUrl:
      "https://images.unsplash.com/photo-1502622796232-e88458466c33?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2532&q=80",
  },
  {
    id: 6,
    title: "Marta Rastovac",
    imgUrl:
      "https://images.unsplash.com/photo-1643131649345-e173895c5eb6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1064&q=80",
  },
  {
    id: 7,
    title: " Yahir Espinosa",

    imgUrl:
      "https://images.unsplash.com/photo-1643080316353-a309869a01a5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 8,
    title: "Sasha Rubaniuk",

    imgUrl:
      "https://images.unsplash.com/photo-1643961058847-23a76d3c8b6e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1093&q=80",
  },
  {
    id: 9,
    title: "Pawel Czerwinski",

    imgUrl:
      "https://images.unsplash.com/photo-1636667472926-8f5836089aad?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 10,
    title: "Dynamic Wang",
    navId: 2,
    imgUrl:
      "https://images.unsplash.com/photo-1639738415512-1f122497ef9c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80",
  },
  {
    id: 11,
    title: "SIMON LEE",
    imgUrl:
      "https://images.unsplash.com/photo-1640595635946-cf301352aa38?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1480&q=80",
  },
  {
    id: 12,
    title: "Marek Piwnicki",

    imgUrl:
      "https://images.unsplash.com/photo-1643828029679-92c0d7ef9ab8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2532&q=80",
  },
  {
    id: 13,
    title: "Atik sulianami",

    imgUrl:
      "https://images.unsplash.com/photo-1558616629-899031969d5e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 14,
    title: "Elizaveta Ivanova",

    imgUrl:
      "https://images.unsplash.com/photo-1643650897198-c5743e9f24f6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=597&q=80",
  },
  {
    id: 15,
    title: "Pawel Czerwinski",
    imgUrl:
      "https://images.unsplash.com/photo-1631465416799-02880b27977e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 16,
    title: "Shubham Dhage",
    imgUrl:
      "https://images.unsplash.com/photo-1643632406503-67e55e5ba526?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2664&q=80Ï",
  },
  {
    id: 17,
    title: "Smit Patel",
    imgUrl:
      "https://images.unsplash.com/photo-1544772546-4357b9384b60?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=927&q=80",
  },
  {
    id: 18,
    title: "Prasad Jadhav",
    imgUrl:
      "https://images.unsplash.com/photo-1641025389841-123ffcff3aa4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 19,
    title: "Mingwei Lim",
    imgUrl:
      "https://images.unsplash.com/photo-1641892157175-8fe6d756e459?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1480&q=80",
  },
  {
    id: 20,
    title: "Icarius",
    navId: 3,
    imgUrl:
      "https://images.unsplash.com/photo-1642059870522-bb7a747cb4c1?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=927&q=80",
  },
  {
    id: 21,
    title: "Andrew Kliatskyi",
    imgUrl:
      "https://images.unsplash.com/photo-1628694647734-bf4aedeede1e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 22,
    title: "Clay LeConey",
    imgUrl:
      "https://images.unsplash.com/photo-1643125082496-6962167d8961?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 23,
    title: "NIKHIL",
    imgUrl:
      "https://images.unsplash.com/photo-1643260669988-31da7ec61233?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1035&q=80",
  },
  {
    id: 24,
    title: "Solen Feyissa",
    imgUrl:
      "https://images.unsplash.com/photo-1641663322189-58ad80addf47?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 25,
    title: "Pawel Czerwinski",
    imgUrl:
      "https://images.unsplash.com/photo-1643557763588-da65ca5e33a8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
  },
  {
    id: 26,
    title: "Sumaid pal Singh Bakshi",
    imgUrl:
      "https://images.unsplash.com/photo-1642777693199-aa4c624aac8e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1567&q=80",
  },
  {
    id: 27,
    title: "Nathan Watson",
    navId: 4,
    imgUrl:
      "https://images.unsplash.com/photo-1643228995868-bf698f67d053?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80",
  },
  {
    id: 28,
    title: "Daniel Olah",
    imgUrl:
      "https://images.unsplash.com/photo-1541356665065-22676f35dd40?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=927&q=80",
  },
  {
    id: 29,
    title: "Pawel Czerwinski",
    imgUrl:
      "https://images.unsplash.com/photo-1577138043155-7934dd897541?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1480&q=80",
  },
  {
    id: 30,
    title: "Jannik Selz",
    imgUrl:
      "https://images.unsplash.com/photo-1545170127-1abebd200162?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 31,
    title: "Aleksandra Khaprenko",
    imgUrl:
      "https://images.unsplash.com/photo-1547628641-ec2098bb5812?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80",
  },
  {
    id: 32,
    title: "Rodion Kutsaev",
    navId: 5,
    imgUrl:
      "https://images.unsplash.com/photo-1550684849-39df3781f7b0?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80",
  },
  {
    id: 33,
    title: "Rodion Kutsaev",
    imgUrl:
      "https://images.unsplash.com/photo-1445630945852-d2fe3e22edf9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80",
  },
  {
    id: 34,
    title: "Allec Gomes",
    imgUrl:
      "https://images.unsplash.com/photo-1615773146406-277d9d3e7c2f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
  {
    id: 35,
    title: "J Lee",
    imgUrl:
      "https://images.unsplash.com/photo-1605003179269-c446bb939f00?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80",
  },
];
